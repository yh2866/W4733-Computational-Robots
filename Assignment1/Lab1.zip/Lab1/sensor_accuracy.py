from gopigo import *


if __name__ == "__main__":

	servo(90)
	while True:
		print us_dist(15)

 	stop()
